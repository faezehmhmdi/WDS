version_tuple = (2019, 1, 1)
version = ".".join(str(n) for n in version_tuple)
